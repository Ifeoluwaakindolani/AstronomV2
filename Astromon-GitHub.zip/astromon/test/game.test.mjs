import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {newPlayer,action,award} from '../engine.mjs';
import {planets,species,areas} from '../public/world.mjs';
test('all 190 species have valid planet and artwork mappings',()=>{assert.equal(species.length,190);assert.equal(planets.length,10);assert.equal(species[6].name,'Metamon');species.forEach((s,i)=>{assert.equal(s.id,i);assert.ok(s.art>=0&&s.art<(s.artSheet==='animals'?12:6));assert.ok(planets[s.planet]);});});
test('level gates, exploration areas, training, mission claims, and caps',()=>{const p=newPlayer();assert.throws(()=>action(p,'starter',1));assert.throws(()=>action(p,'teleport',1));award(p,115,0);assert.equal(p.level,2);action(p,'teleport',1);assert.deepEqual(p.visited,[0,1]);for(const a of areas){action(p,'explore',a.id);assert.equal(p.battle.area,a.id);assert.equal(species[p.battle.species].planet,1);action(p,'flee');}assert.throws(()=>action(p,'explore',44));p.caught=1;action(p,'claim','first');assert.throws(()=>action(p,'claim','first'));p.coins=0;assert.throws(()=>action(p,'buy'));award(p,100000,0);assert.equal(p.level,10);action(p,'teleport',9);});
test('wild defeat recovers the crew; combat cannot be replayed after escape',()=>{const p=newPlayer();action(p,'explore',2);p.team[0].hp=1;p.battle.hp=1000;action(p,'attack','basic');assert.equal(p.battle,null);assert.ok(p.team[0].hp>1);assert.throws(()=>action(p,'attack','special'));});
test('accounts persist, sessions enforce access, and two trainers finish real PvP',async()=>{const dir=await mkdtemp(path.join(tmpdir(),'astromon-test-'));let child;
async function start(){child=spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,PORT:'0',HOST:'127.0.0.1',DATA_DIR:dir},stdio:['ignore','pipe','pipe']});return await new Promise((resolve,reject)=>{let out='';const timer=setTimeout(()=>reject(Error('Server start timeout')),10000);child.stdout.on('data',d=>{out+=d;const m=out.match(/http:\/\/127.0.0.1:\d+/);if(m){clearTimeout(timer);resolve(m[0]);}});child.on('error',reject);child.on('exit',code=>{if(!out.includes('ready')){clearTimeout(timer);reject(Error('Server exited '+code));}});});}
async function stop(){if(child&&!child.killed)await new Promise(resolve=>{child.once('exit',resolve);child.kill();});}
try{let base=await start();async function request(route,body,cookie){const r=await fetch(base+'/api/'+route,{...(body?{method:'POST',headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:JSON.stringify(body)}:{headers:cookie?{Cookie:cookie}:{}})});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
assert.equal((await request('state')).status,401);const a=await request('register',{name:'trainer_a',password:'test_password_a'}),b=await request('register',{name:'trainer_b',password:'test_password_b'});assert.equal(a.status,200);assert.equal(b.status,200);assert.ok(a.cookie);assert.equal((await request('login',{name:'trainer_a',password:'wrong_password'})).status,400);assert.equal((await request('state',null,a.cookie)).data.player.team.length,3);assert.equal((await request('state',null,b.cookie)).data.player.team.length,3);assert.equal((await request('action',{kind:'starter',value:0},a.cookie)).status,400);assert.equal((await request('action',{kind:'teleport',value:9},a.cookie)).status,400);await request('pvp',{kind:'queue'},a.cookie);await request('pvp',{kind:'queue'},b.cookie);let sa=(await request('state',null,a.cookie)).data;assert.equal(sa.match.opponentName,'trainer_b');assert.equal((await request('action',{kind:'rest'},a.cookie)).status,400);for(let i=0;i<10&&!sa.match.done;i++){assert.equal((await request('pvp',{kind:'move',value:'basic'},a.cookie)).status,200);assert.equal((await request('pvp',{kind:'move',value:'basic'},a.cookie)).status,400);assert.equal((await request('pvp',{kind:'move',value:'basic'},b.cookie)).status,200);sa=(await request('state',null,a.cookie)).data;}assert.equal(sa.match.done,true);assert.equal(sa.player.pvp,1);await request('pvp',{kind:'leave'},a.cookie);assert.equal((await request('state',null,a.cookie)).data.match,null);await request('pvp',{kind:'leave'},b.cookie);
await request('pvp',{kind:'create-room'},a.cookie);
const room=(await request('state',null,a.cookie)).data.friendRoom;
assert.match(room,/^[A-F0-9]{8}$/);
assert.equal((await request('pvp',{kind:'join-room',value:room},a.cookie)).status,400);
assert.equal((await request('pvp',{kind:'queue'},a.cookie)).status,400);
assert.equal((await request('action',{kind:'rest'},a.cookie)).status,400);
assert.equal((await request('pvp',{kind:'join-room',value:'INVALID'},b.cookie)).status,400);
assert.equal((await request('pvp',{kind:'join-room',value:room.toLowerCase()},b.cookie)).status,200);
assert.equal((await request('state',null,a.cookie)).data.friendRoom,null);
assert.equal((await request('state',null,a.cookie)).data.match.opponentName,'trainer_b');
await request('pvp',{kind:'move',value:'special'},a.cookie);
await request('pvp',{kind:'move',value:'guard'},b.cookie);
assert.equal((await request('state',null,a.cookie)).data.match.round,2);
await request('pvp',{kind:'forfeit'},b.cookie);
assert.equal((await request('state',null,a.cookie)).data.match.result,'win');
assert.equal((await request('pvp',{kind:'forfeit'},b.cookie)).status,400);
await request('pvp',{kind:'leave'},a.cookie);
await request('pvp',{kind:'leave'},b.cookie);
await request('pvp',{kind:'create-room'},a.cookie);
await request('pvp',{kind:'close-room'},a.cookie);
assert.equal((await request('state',null,a.cookie)).data.friendRoom,null);
await stop();base=await start();const login=await request('login',{name:'trainer_a',password:'test_password_a'});assert.equal(login.status,200);const saved=(await request('state',null,login.cookie)).data;assert.equal(saved.player.team.length,3);assert.equal(saved.player.pvp,2);await request('logout',{},login.cookie);assert.equal((await request('state',null,login.cookie)).status,401);
}finally{await stop();await rm(dir,{recursive:true,force:true});}});
