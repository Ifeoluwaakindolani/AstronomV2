import test from 'node:test';
import assert from 'node:assert/strict';
import {newPlayer,action} from '../engine.mjs';
import {trainers,maxHp} from '../public/world.mjs';

test('new trainers receive exactly three healthy level-one Astromon once',()=>{
 const p=newPlayer();
 assert.deepEqual(p.team.map(c=>c.species),[0,1,2]);
 assert.equal(new Set(p.team.map(c=>c.uid)).size,3);
 for(const c of p.team){assert.equal(c.level,1);assert.equal(c.hp,maxHp(c));}
 assert.throws(()=>action(p,'starter',0),/already/);
 assert.equal(p.team.length,3);
});

test('legacy empty accounts receive the three starters once with chosen leader',()=>{
 const p=newPlayer();p.team=[];action(p,'starter',2);
 assert.deepEqual(p.team.map(c=>c.species),[2,0,1]);
 assert.throws(()=>action(p,'starter',1));
});

test('computer opponents always match player level and cannot be captured',()=>{
 for(const level of [1,5,10])for(const trainer of trainers){
  const p=newPlayer();p.level=level;const capsules=p.capsules;
  action(p,'trainer',trainer.id);
  assert.equal(p.battle.level,level);assert.equal(p.battle.kind,'trainer');
  assert.equal(p.battle.trainerName,trainer.name);
  assert.throws(()=>action(p,'catch'),/cannot capture/);
  assert.equal(p.capsules,capsules);assert.equal(p.team.length,3);
  assert.throws(()=>action(p,'trainer',trainer.id));
  action(p,'flee');assert.equal(p.battle,null);
 }
});

test('trainer wins award rewards once and do not count as wild victories',()=>{
 const p=newPlayer();action(p,'trainer','luma');p.battle.hp=1;
 action(p,'attack','basic');
 assert.equal(p.trainerWins,1);assert.equal(p.wins,0);
 assert.equal(p.xp,45);assert.equal(p.coins,130);assert.equal(p.battle,null);
 assert.throws(()=>action(p,'attack','basic'));
 assert.equal(p.coins,130);
 assert.throws(()=>action(p,'trainer','fake-opponent'));
});
